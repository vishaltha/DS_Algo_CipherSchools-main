[View Problem](https://leetcode.com/problems/delete-node-in-a-linked-list)
