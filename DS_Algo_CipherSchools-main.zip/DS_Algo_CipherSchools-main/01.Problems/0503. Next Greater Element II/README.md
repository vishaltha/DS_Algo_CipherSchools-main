[View Problem](https://leetcode.com/problems/next-greater-element-ii/)
